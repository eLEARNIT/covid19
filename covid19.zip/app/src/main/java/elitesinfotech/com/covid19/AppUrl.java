package elitesinfotech.com.covid19;

public class AppUrl {
    public static String MainUrl="https://corona.lmao.ninja/v2/all";
    public static String SubMainUrl="https://corona.lmao.ninja/v2/countries";
}
